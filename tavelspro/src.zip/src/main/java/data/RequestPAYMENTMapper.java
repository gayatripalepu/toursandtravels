package data; 
  public class RequestPAYMENTMapper implements RequestMapper<business.PAYMENT>
 { 

 public business.PAYMENT mapRequest(jakarta.servlet.http.HttpServletRequest req) throws jakarta.servlet.ServletException  
 {
	business.PAYMENT  obj = new business.PAYMENT(); 
	obj.setPAYMENTMETHOD(req.getParameter("txtpaymentmethod"));
	obj.setAMOUNT(Integer.parseInt(req.getParameter("txtamount")));
	obj.setPAYMENTID(Integer.parseInt(req.getParameter("txtpaymentid")));
	//obj.setPAYMENTDATE(req.getParameter("txtpaymentdate"));
	//obj.setSTATUS(req.getParameter("txtstatus"));
	
	
	return obj; 

 } 
 } 

